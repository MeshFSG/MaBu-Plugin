<?php // Silent is gold
