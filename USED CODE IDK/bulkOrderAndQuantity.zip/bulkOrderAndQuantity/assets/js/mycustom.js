jQuery(function($){
	// simple multiple select
	$('#pa_imprint_color').select2();
	$('#pa_imprint_location').select2();
	$('#pa_imprint_type').select2();
    
});